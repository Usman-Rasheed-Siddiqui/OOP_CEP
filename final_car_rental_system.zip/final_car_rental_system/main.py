
from main_interface import Interface

if __name__ == '__main__':
    app = Interface()
    app.clear_screen()
    app.main_menu()
