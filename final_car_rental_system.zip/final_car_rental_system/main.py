
from main_interface import Interface

if __name__ == '__main__':
    app = Interface()
    app.main_menu()
