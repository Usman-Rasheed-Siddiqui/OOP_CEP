
from rental.rental_manager import RentalManager
from users.admin import Admin
from users.customer import Customer
from vehicles.car import Car

def main():
    manager = RentalManager()

