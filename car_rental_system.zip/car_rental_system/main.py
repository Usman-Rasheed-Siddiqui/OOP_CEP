
from car_rental_system import main



if __name__ == '__main__':
    """Start the car rental system"""
    main()
